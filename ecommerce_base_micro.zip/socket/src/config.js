// eslint-disable-next-line import/prefer-default-export
export const SOCKET_NOTIFICATION_MESSAGE = 'notification-message';
export const SOCKET_NOTIFICATION_CLIENT = 'notification-client';
