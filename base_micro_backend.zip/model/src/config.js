/* eslint-disable import/prefer-default-export */
export const POSTED = 'POSTED';
export const CREATED = 'CREATED';
export const WAITING_FOR_SCAN = 'WAITING_FOR_SCAN';
